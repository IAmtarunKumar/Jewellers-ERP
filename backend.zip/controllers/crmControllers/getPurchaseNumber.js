const getPurchaseNumber = async (req, res) => {
    console.log("we hit the getPurchase number api")

}

module.exports = getPurchaseNumber